<?php 
	include("header.php");
	include("connect.php");
	error_reporting(2);
 ?>
 <style type="text/css">
	table tr td {
	    border-bottom: 2px solid #ccc;
	    padding-left: 12px;
	    padding-right: 12px;
	}
	th {
		padding-left: 35px;
	}
	td{
		text-align: center;
	}
	.icon{
		color: red;
	}
</style>
 <div class="container">
 	<div class="row" style="margin-left: 15px;">
 		<div class="col-md-1">
 			
 		</div>
 		<div class="col-md-11">
 			<?php 
				$sql="select * from products";
				$result = mysqli_query($conn,$sql);
		?>
		<table>
	    <thead>
	        <tr>
	            <!-- <th>ID</th> -->
	            <th>name</th>
	            <th>price</th>
	            <th>old_price</th>
	            <th>quantity</th>
	            <th>description</th>
	            <th>img</th>
	            <th>#</th>
	        </tr>
	    </thead>
	    <tbody>
	        <?php 
	        	while ($row = mysqli_fetch_array($result)): ?>
	            <tr>
	                <td><?php echo $row['name']; ?></td>
	                <td><?php echo $row['price']; ?></td>
	                <td><?php echo $row['old_price']; ?></td>
	                <td><?php echo $row['quantity'];  ?></td>  
	                <td><?php echo $row['description']; ?></td>  
	                <td><img class="img-thumbnail" src="<?php echo '../images/' .$row['img']; ?>" alt="" height="200" width="200"></td>
	                <td>
	                	<a href="update_product.php?id=<?php echo $row['id'] ?>">
	                		<button type="button" class="btn btn-warning btn-sm">update
					          	<!-- <span class="glyphicon glyphicon-pencil"></span>  	 -->
					        </button>
	                	</a>
	                	<a href="delete_product.php?id=<?php echo $row['id'] ?>" >
	                		<button type="button" class="btn btn-danger btn-sm">delete
								<!-- <i class="fa fa-trash"></i> -->
					        </button>
	                	</a>
	                	
	                </td>
	            </tr>
	        <?php 
	    		endwhile; 
	    	?>
	    </tbody>
	</table>
		
		
 		</div>
 	</div>
 </div>